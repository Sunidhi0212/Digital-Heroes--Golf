import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Plus, Trophy, Calendar } from "lucide-react"
import { DrawActions } from "@/components/admin/draw-actions"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { WinnersTable } from "@/components/admin/winners-table"

async function getDrawsData() {
  const supabase = await createClient()
  
  const { data: draws } = await supabase
    .from("draws")
    .select("*")
    .order("draw_date", { ascending: false })

  const { data: winners } = await supabase
    .from("winners")
    .select("*, profiles(*), draws(*)")
    .order("created_at", { ascending: false })

  return { draws: draws ?? [], winners: winners ?? [] }
}

export default async function AdminDrawsPage() {
  const { draws, winners } = await getDrawsData()

  const pendingWinners = winners.filter(w => w.verification_status === "pending")
  const approvedWinners = winners.filter(w => w.verification_status === "approved")

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Prize Draws</h1>
          <p className="text-muted-foreground">
            Manage monthly prize draws and winners
          </p>
        </div>
        
        <Button asChild className="gap-2">
          <Link href="/admin/draws/new">
            <Plus className="h-4 w-4" />
            Create Draw
          </Link>
        </Button>
      </div>

      <Tabs defaultValue="draws">
        <TabsList>
          <TabsTrigger value="draws">Draws</TabsTrigger>
          <TabsTrigger value="winners" className="gap-2">
            Winners
            {pendingWinners.length > 0 && (
              <Badge variant="destructive" className="ml-1">
                {pendingWinners.length}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="draws" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>All Draws</CardTitle>
              <CardDescription>
                {draws.length} draw{draws.length !== 1 ? "s" : ""} created
              </CardDescription>
            </CardHeader>
            <CardContent>
              {draws.length > 0 ? (
                <div className="space-y-4">
                  {draws.map((draw) => (
                    <div 
                      key={draw.id}
                      className="flex items-center justify-between rounded-lg border border-border p-4"
                    >
                      <div className="flex items-center gap-4">
                        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                          <Trophy className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-medium">
                              {new Date(draw.draw_date).toLocaleDateString("en-GB", {
                                month: "long",
                                year: "numeric"
                              })}
                            </h3>
                            <Badge variant={
                              draw.status === "published" ? "default" : 
                              draw.status === "simulated" ? "secondary" : "outline"
                            }>
                              {draw.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {draw.total_subscribers} subscribers
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-4">
                        {/* Winning Numbers */}
                        {draw.winning_numbers && draw.winning_numbers.length > 0 && (
                          <div className="hidden items-center gap-1 sm:flex">
                            {draw.winning_numbers.map((num: number, i: number) => (
                              <div 
                                key={i}
                                className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary"
                              >
                                {num}
                              </div>
                            ))}
                          </div>
                        )}
                        
                        <div className="text-right">
                          <p className="font-medium">${Number(draw.prize_pool_5_match).toFixed(0)}</p>
                          <p className="text-xs text-muted-foreground">Jackpot</p>
                        </div>
                        
                        <DrawActions draw={draw} />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Calendar className="mb-4 h-12 w-12 text-muted-foreground" />
                  <h3 className="mb-2 font-semibold">No draws yet</h3>
                  <p className="mb-4 text-sm text-muted-foreground">
                    Create your first monthly prize draw
                  </p>
                  <Button asChild>
                    <Link href="/admin/draws/new">Create Draw</Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="winners" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Winner Verification</CardTitle>
              <CardDescription>
                Review and verify draw winners
              </CardDescription>
            </CardHeader>
            <CardContent>
              <WinnersTable winners={winners} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
