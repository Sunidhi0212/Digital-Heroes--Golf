import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Heart, Trophy, Target } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden py-20 md:py-32">
      {/* Background gradient */}
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-primary/5 via-background to-background" />
      
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-4xl text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-sm text-primary">
            <Heart className="h-4 w-4" />
            <span>10%+ of every subscription goes to charity</span>
          </div>
          
          <h1 className="mb-6 text-balance text-4xl font-bold tracking-tight text-foreground md:text-6xl lg:text-7xl">
            Golf. Give. <span className="text-primary">Win.</span>
          </h1>
          
          <p className="mx-auto mb-10 max-w-2xl text-pretty text-lg text-muted-foreground md:text-xl">
            Transform your golf scores into chances to win monthly prizes while supporting charities you care about. 
            Every round you play makes a difference.
          </p>
          
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button size="lg" asChild className="gap-2">
              <Link href="/auth/sign-up">
                Start Your Journey
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/#how-it-works">See How It Works</Link>
            </Button>
          </div>
        </div>
        
        {/* Stats */}
        <div className="mt-20 grid gap-8 md:grid-cols-3">
          <div className="flex flex-col items-center gap-2 rounded-2xl border border-border bg-card p-8 text-center shadow-sm">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <Trophy className="h-6 w-6 text-primary" />
            </div>
            <div className="text-3xl font-bold text-foreground">Monthly</div>
            <div className="text-muted-foreground">Prize Draws</div>
          </div>
          
          <div className="flex flex-col items-center gap-2 rounded-2xl border border-border bg-card p-8 text-center shadow-sm">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent/20">
              <Heart className="h-6 w-6 text-accent-foreground" />
            </div>
            <div className="text-3xl font-bold text-foreground">10%+</div>
            <div className="text-muted-foreground">To Charity</div>
          </div>
          
          <div className="flex flex-col items-center gap-2 rounded-2xl border border-border bg-card p-8 text-center shadow-sm">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <Target className="h-6 w-6 text-primary" />
            </div>
            <div className="text-3xl font-bold text-foreground">5 Scores</div>
            <div className="text-muted-foreground">Your Lucky Numbers</div>
          </div>
        </div>
      </div>
    </section>
  )
}
