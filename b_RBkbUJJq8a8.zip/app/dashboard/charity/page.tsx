import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CharitySelector } from "@/components/dashboard/charity-selector"
import { Heart, ExternalLink } from "lucide-react"
import Link from "next/link"

async function getCharityData(userId: string) {
  const supabase = await createClient()
  
  // Get user profile with charity
  const { data: profile } = await supabase
    .from("profiles")
    .select("*, charities(*)")
    .eq("id", userId)
    .single()

  // Get all active charities
  const { data: charities } = await supabase
    .from("charities")
    .select("*")
    .eq("is_active", true)
    .order("is_featured", { ascending: false })

  // Get user's donation history
  const { data: donations } = await supabase
    .from("charity_donations")
    .select("*, charities(*)")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .limit(10)

  return { 
    profile, 
    charities: charities ?? [], 
    donations: donations ?? [] 
  }
}

export default async function CharityPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) return null

  const { profile, charities, donations } = await getCharityData(user.id)

  // Calculate total donated
  const totalDonated = donations.reduce((sum, d) => sum + Number(d.amount), 0)

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">My Charity</h1>
        <p className="text-muted-foreground">
          Manage your charity selection and view your contribution history
        </p>
      </div>

      {/* Current Charity */}
      <Card>
        <CardHeader>
          <CardTitle>Your Selected Charity</CardTitle>
          <CardDescription>
            {profile?.charity_contribution_percentage ?? 10}% of your subscription goes to this charity
          </CardDescription>
        </CardHeader>
        <CardContent>
          {profile?.charities ? (
            <div className="flex items-start gap-4">
              <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-primary/10">
                <Heart className="h-8 w-8 text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-semibold">{profile.charities.name}</h3>
                <p className="mt-1 text-muted-foreground">{profile.charities.description}</p>
                {profile.charities.website_url && (
                  <Link 
                    href={profile.charities.website_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2 inline-flex items-center gap-1 text-sm text-primary hover:underline"
                  >
                    Visit Website
                    <ExternalLink className="h-3 w-3" />
                  </Link>
                )}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <Heart className="mb-4 h-12 w-12 text-muted-foreground" />
              <h3 className="mb-2 font-semibold">No charity selected</h3>
              <p className="text-sm text-muted-foreground">
                Choose a charity below to support with your subscription
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Contributed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">${totalDonated.toFixed(2)}</div>
            <p className="text-sm text-muted-foreground">
              Across {donations.length} payment{donations.length !== 1 ? "s" : ""}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Contribution Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{profile?.charity_contribution_percentage ?? 10}%</div>
            <p className="text-sm text-muted-foreground">
              Of your subscription
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Change Charity */}
      <Card>
        <CardHeader>
          <CardTitle>Change Charity</CardTitle>
          <CardDescription>
            Select a different charity to support
          </CardDescription>
        </CardHeader>
        <CardContent>
          <CharitySelector 
            charities={charities} 
            currentCharityId={profile?.selected_charity_id}
            userId={user.id}
          />
        </CardContent>
      </Card>

      {/* Contribution History */}
      <Card>
        <CardHeader>
          <CardTitle>Contribution History</CardTitle>
          <CardDescription>
            Record of donations made through your subscription
          </CardDescription>
        </CardHeader>
        <CardContent>
          {donations.length > 0 ? (
            <div className="space-y-3">
              {donations.map((donation) => (
                <div 
                  key={donation.id}
                  className="flex items-center justify-between rounded-lg border border-border p-4"
                >
                  <div>
                    <p className="font-medium">{donation.charities?.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(donation.created_at).toLocaleDateString("en-GB", {
                        year: "numeric",
                        month: "long",
                        day: "numeric"
                      })}
                    </p>
                  </div>
                  <div className="text-lg font-semibold text-primary">
                    ${Number(donation.amount).toFixed(2)}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-8 text-center text-muted-foreground">
              No contributions yet. Subscribe to start supporting your chosen charity.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
