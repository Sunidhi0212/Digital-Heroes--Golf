import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CharityForm } from "@/components/admin/charity-form"
import { CharityActions } from "@/components/admin/charity-actions"
import { Plus, Heart } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

async function getCharities() {
  const supabase = await createClient()
  
  const { data: charities } = await supabase
    .from("charities")
    .select("*")
    .order("is_featured", { ascending: false })
    .order("name")

  return charities ?? []
}

export default async function AdminCharitiesPage() {
  const charities = await getCharities()

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Charities</h1>
          <p className="text-muted-foreground">
            Manage partner charities
          </p>
        </div>
        
        <Dialog>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Add Charity
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Charity</DialogTitle>
            </DialogHeader>
            <CharityForm />
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Charities</CardTitle>
          <CardDescription>
            {charities.length} partner charit{charities.length !== 1 ? "ies" : "y"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {charities.length > 0 ? (
            <div className="space-y-4">
              {charities.map((charity) => (
                <div 
                  key={charity.id}
                  className="flex items-center justify-between rounded-lg border border-border p-4"
                >
                  <div className="flex items-center gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                      <Heart className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{charity.name}</h3>
                        {charity.is_featured && (
                          <Badge variant="secondary">Featured</Badge>
                        )}
                        {!charity.is_active && (
                          <Badge variant="destructive">Inactive</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-1">
                        {charity.description}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="font-medium">${Number(charity.total_received).toFixed(2)}</p>
                      <p className="text-xs text-muted-foreground">Total received</p>
                    </div>
                    <CharityActions charity={charity} />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Heart className="mb-4 h-12 w-12 text-muted-foreground" />
              <h3 className="mb-2 font-semibold">No charities yet</h3>
              <p className="text-sm text-muted-foreground">
                Add your first partner charity to get started
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
