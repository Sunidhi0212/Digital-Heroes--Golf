import { Heart, ArrowRight } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/server"

async function getCharities() {
  const supabase = await createClient()
  const { data: charities } = await supabase
    .from("charities")
    .select("*")
    .eq("is_active", true)
    .order("is_featured", { ascending: false })
    .limit(6)
  return charities ?? []
}

export async function CharitiesSection() {
  const charities = await getCharities()

  return (
    <section id="charities" className="border-t border-border bg-card py-20 md:py-32">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-sm text-primary">
            <Heart className="h-4 w-4" />
            <span>Making a Difference Together</span>
          </div>
          
          <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">
            Support Causes You Care About
          </h2>
          <p className="text-lg text-muted-foreground">
            Choose from our partner charities. At least 10% of your subscription goes directly 
            to your selected charity every month.
          </p>
        </div>
        
        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {charities.length > 0 ? (
            charities.map((charity) => (
              <div 
                key={charity.id}
                className="group relative overflow-hidden rounded-2xl border border-border bg-background p-6 transition-all hover:border-primary/50 hover:shadow-md"
              >
                {charity.is_featured && (
                  <div className="absolute right-4 top-4">
                    <span className="rounded-full bg-accent/20 px-2 py-0.5 text-xs font-medium text-accent-foreground">
                      Featured
                    </span>
                  </div>
                )}
                
                <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-primary/10">
                  <Heart className="h-8 w-8 text-primary" />
                </div>
                
                <h3 className="mb-2 text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                  {charity.name}
                </h3>
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {charity.description}
                </p>
              </div>
            ))
          ) : (
            // Fallback for when no charities are loaded
            <>
              {[
                { name: "Cancer Research UK", description: "Funding research to beat cancer" },
                { name: "British Heart Foundation", description: "Fighting heart and circulatory diseases" },
                { name: "Macmillan Cancer Support", description: "Supporting people living with cancer" },
                { name: "Mind", description: "Mental health charity" },
                { name: "Alzheimers Society", description: "Supporting people affected by dementia" },
                { name: "RSPCA", description: "Animal welfare charity" }
              ].map((charity, i) => (
                <div 
                  key={i}
                  className="group relative overflow-hidden rounded-2xl border border-border bg-background p-6 transition-all hover:border-primary/50 hover:shadow-md"
                >
                  <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-primary/10">
                    <Heart className="h-8 w-8 text-primary" />
                  </div>
                  
                  <h3 className="mb-2 text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                    {charity.name}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {charity.description}
                  </p>
                </div>
              ))}
            </>
          )}
        </div>
        
        <div className="mt-12 text-center">
          <Button variant="outline" asChild className="gap-2">
            <Link href="/charities">
              View All Partner Charities
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
