import { UserPlus, Target, Calendar, Trophy } from "lucide-react"

const steps = [
  {
    icon: UserPlus,
    title: "Subscribe",
    description: "Join Birdie Fund and choose your favorite charity. Your subscription directly supports causes you care about.",
    step: "01"
  },
  {
    icon: Target,
    title: "Play & Submit",
    description: "Play golf and submit your Stableford scores. We track your rolling 5 most recent scores as your draw numbers.",
    step: "02"
  },
  {
    icon: Calendar,
    title: "Monthly Draw",
    description: "At the end of each month, 5 winning numbers are drawn. Match 3, 4, or all 5 to win from the prize pool.",
    step: "03"
  },
  {
    icon: Trophy,
    title: "Win & Give",
    description: "Winners claim their prizes while your subscription continues supporting charity. Everyone wins!",
    step: "04"
  }
]

export function HowItWorksSection() {
  return (
    <section id="how-it-works" className="border-t border-border bg-card py-20 md:py-32">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">
            How Birdie Fund Works
          </h2>
          <p className="text-lg text-muted-foreground">
            Your golf scores become your lottery numbers. Play the game you love, 
            support charity, and get chances to win every month.
          </p>
        </div>
        
        <div className="mt-16 grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((step) => (
            <div key={step.step} className="relative">
              <div className="flex flex-col items-center text-center">
                <div className="mb-4 text-5xl font-bold text-primary/10">{step.step}</div>
                <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
                  <step.icon className="h-7 w-7 text-primary" />
                </div>
                <h3 className="mb-2 text-xl font-semibold text-foreground">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 rounded-2xl border border-primary/20 bg-primary/5 p-8 md:p-12">
          <div className="mx-auto max-w-3xl text-center">
            <h3 className="mb-4 text-2xl font-bold text-foreground">Understanding Your Numbers</h3>
            <p className="text-muted-foreground">
              Your draw entry is based on your <strong className="text-foreground">rolling 5 most recent Stableford scores</strong>. 
              Stableford scores typically range from 1-45 points. As you submit new scores, 
              your oldest score drops off, keeping your numbers fresh and tied to your actual golf performance.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
