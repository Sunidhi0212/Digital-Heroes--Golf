"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Heart, Check, Loader2 } from "lucide-react"

interface Charity {
  id: string
  name: string
  description: string
  is_featured: boolean
}

interface CharitySelectorProps {
  charities: Charity[]
  currentCharityId?: string
  userId: string
}

export function CharitySelector({ charities, currentCharityId, userId }: CharitySelectorProps) {
  const [selectedId, setSelectedId] = useState<string | null>(currentCharityId ?? null)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  const handleSave = async () => {
    if (!selectedId || selectedId === currentCharityId) return

    setLoading(true)
    setError(null)
    setSuccess(false)

    const { error: updateError } = await supabase
      .from("profiles")
      .update({ selected_charity_id: selectedId })
      .eq("id", userId)

    if (updateError) {
      setError(updateError.message)
      setLoading(false)
      return
    }

    setSuccess(true)
    setLoading(false)
    router.refresh()
  }

  return (
    <div className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="border-primary/50 bg-primary/5">
          <Check className="h-4 w-4 text-primary" />
          <AlertDescription className="text-primary">
            Charity updated successfully!
          </AlertDescription>
        </Alert>
      )}

      <div className="grid gap-3 sm:grid-cols-2">
        {charities.map((charity) => (
          <button
            key={charity.id}
            type="button"
            onClick={() => setSelectedId(charity.id)}
            className={`relative w-full rounded-lg border p-4 text-left transition-all ${
              selectedId === charity.id
                ? "border-primary bg-primary/5"
                : "border-border hover:border-primary/50"
            }`}
          >
            {charity.is_featured && (
              <span className="absolute right-3 top-3 rounded-full bg-accent/20 px-2 py-0.5 text-xs font-medium text-accent-foreground">
                Featured
              </span>
            )}
            
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                <Heart className="h-5 w-5 text-primary" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="font-medium">{charity.name}</h3>
                <p className="mt-1 text-sm text-muted-foreground line-clamp-2">
                  {charity.description}
                </p>
              </div>
              {selectedId === charity.id && (
                <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary">
                  <Check className="h-4 w-4 text-primary-foreground" />
                </div>
              )}
            </div>
          </button>
        ))}
      </div>

      <Button 
        onClick={handleSave} 
        disabled={!selectedId || selectedId === currentCharityId || loading}
        className="w-full sm:w-auto"
      >
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Saving...
          </>
        ) : (
          "Save Charity Selection"
        )}
      </Button>
    </div>
  )
}
