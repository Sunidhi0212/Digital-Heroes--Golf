"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Check, CreditCard } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

interface Subscription {
  id: string
  plan_type: string
  amount: number
  starts_at: string
  ends_at: string
}

interface SubscriptionManagerProps {
  userId: string
  currentStatus: string
  currentPlan?: string
  subscription?: Subscription
}

export function SubscriptionManager({ 
  userId, 
  currentStatus, 
  currentPlan,
  subscription 
}: SubscriptionManagerProps) {
  const [loading, setLoading] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<"monthly" | "yearly">("monthly")
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  // Mock subscription activation (in real app, this would go through Stripe)
  const handleSubscribe = async () => {
    setLoading(true)
    setError(null)

    const amount = selectedPlan === "monthly" ? 9.99 : 99
    const charityAmount = amount * 0.1 // 10%
    const prizePoolAmount = amount - charityAmount

    const now = new Date()
    const endsAt = new Date(now)
    if (selectedPlan === "monthly") {
      endsAt.setMonth(endsAt.getMonth() + 1)
    } else {
      endsAt.setFullYear(endsAt.getFullYear() + 1)
    }

    // Create subscription record
    const { error: subError } = await supabase
      .from("subscriptions")
      .insert({
        user_id: userId,
        plan_type: selectedPlan,
        amount,
        charity_amount: charityAmount,
        prize_pool_amount: prizePoolAmount,
        starts_at: now.toISOString(),
        ends_at: endsAt.toISOString()
      })

    if (subError) {
      setError(subError.message)
      setLoading(false)
      return
    }

    // Update profile
    const { error: profileError } = await supabase
      .from("profiles")
      .update({
        subscription_status: "active",
        subscription_plan: selectedPlan,
        subscription_start_date: now.toISOString(),
        subscription_end_date: endsAt.toISOString()
      })
      .eq("id", userId)

    if (profileError) {
      setError(profileError.message)
      setLoading(false)
      return
    }

    setSuccess(true)
    setLoading(false)
    router.refresh()
  }

  const handleCancel = async () => {
    setLoading(true)
    setError(null)

    // Update subscription status
    const { error: updateError } = await supabase
      .from("profiles")
      .update({
        subscription_status: "cancelled"
      })
      .eq("id", userId)

    if (updateError) {
      setError(updateError.message)
      setLoading(false)
      return
    }

    if (subscription) {
      await supabase
        .from("subscriptions")
        .update({ status: "cancelled" })
        .eq("id", subscription.id)
    }

    setLoading(false)
    router.refresh()
  }

  if (currentStatus === "active" && subscription) {
    return (
      <div className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="rounded-lg border border-primary/50 bg-primary/5 p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
              <CreditCard className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="font-medium capitalize">{currentPlan} Plan</p>
              <p className="text-sm text-muted-foreground">
                ${subscription.amount}/{currentPlan === "monthly" ? "month" : "year"}
              </p>
            </div>
          </div>
          
          <div className="mt-4 grid gap-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Started</span>
              <span>{new Date(subscription.starts_at).toLocaleDateString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Renews</span>
              <span>{new Date(subscription.ends_at).toLocaleDateString()}</span>
            </div>
          </div>
        </div>

        <Dialog>
          <DialogTrigger asChild>
            <Button variant="outline" className="text-destructive">
              Cancel Subscription
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Cancel Subscription</DialogTitle>
              <DialogDescription>
                Are you sure you want to cancel? You will lose access to prize draws and 
                your charity contributions will stop.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => {}}>
                Keep Subscription
              </Button>
              <Button 
                variant="destructive" 
                onClick={handleCancel}
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Cancelling...
                  </>
                ) : (
                  "Cancel Subscription"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="border-primary/50 bg-primary/5">
          <Check className="h-4 w-4 text-primary" />
          <AlertDescription className="text-primary">
            {"Subscription activated! You're now entered in monthly prize draws."}
          </AlertDescription>
        </Alert>
      )}

      <p className="text-muted-foreground">
        Subscribe to enter monthly prize draws and support your chosen charity.
      </p>

      {/* Plan Selection */}
      <div className="grid gap-4 sm:grid-cols-2">
        <button
          type="button"
          onClick={() => setSelectedPlan("monthly")}
          className={`rounded-lg border p-4 text-left transition-all ${
            selectedPlan === "monthly"
              ? "border-primary bg-primary/5"
              : "border-border hover:border-primary/50"
          }`}
        >
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Monthly</h3>
            {selectedPlan === "monthly" && (
              <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary">
                <Check className="h-3 w-3 text-primary-foreground" />
              </div>
            )}
          </div>
          <p className="mt-1 text-2xl font-bold">$9.99<span className="text-sm font-normal text-muted-foreground">/month</span></p>
          <p className="mt-2 text-sm text-muted-foreground">
            Cancel anytime
          </p>
        </button>

        <button
          type="button"
          onClick={() => setSelectedPlan("yearly")}
          className={`relative rounded-lg border p-4 text-left transition-all ${
            selectedPlan === "yearly"
              ? "border-primary bg-primary/5"
              : "border-border hover:border-primary/50"
          }`}
        >
          <span className="absolute -top-2 right-2 rounded-full bg-accent/20 px-2 py-0.5 text-xs font-medium text-accent-foreground">
            Save 17%
          </span>
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Yearly</h3>
            {selectedPlan === "yearly" && (
              <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary">
                <Check className="h-3 w-3 text-primary-foreground" />
              </div>
            )}
          </div>
          <p className="mt-1 text-2xl font-bold">$99<span className="text-sm font-normal text-muted-foreground">/year</span></p>
          <p className="mt-2 text-sm text-muted-foreground">
            Best value
          </p>
        </button>
      </div>

      <Button 
        onClick={handleSubscribe} 
        className="w-full"
        disabled={loading}
      >
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Processing...
          </>
        ) : (
          `Subscribe - $${selectedPlan === "monthly" ? "9.99/month" : "99/year"}`
        )}
      </Button>

      <p className="text-center text-xs text-muted-foreground">
        This is a demo. In production, this would connect to Stripe for secure payment processing.
      </p>
    </div>
  )
}
