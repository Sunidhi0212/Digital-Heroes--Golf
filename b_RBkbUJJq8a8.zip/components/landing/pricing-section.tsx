"use client"

import { Check } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useState } from "react"

const plans = [
  {
    name: "Monthly",
    price: "9.99",
    period: "/month",
    description: "Perfect for casual golfers",
    features: [
      "Monthly prize draw entry",
      "10%+ to your chosen charity",
      "Track unlimited golf scores",
      "Rolling 5-score entry system",
      "Dashboard & score history",
      "Cancel anytime"
    ],
    cta: "Start Monthly",
    popular: false
  },
  {
    name: "Yearly",
    price: "99",
    period: "/year",
    savings: "Save 17%",
    description: "Best value for dedicated golfers",
    features: [
      "All monthly features",
      "12 monthly draw entries",
      "Priority winner verification",
      "Bonus charity contribution",
      "Early access to new features",
      "Locked-in pricing"
    ],
    cta: "Start Yearly",
    popular: true
  }
]

export function PricingSection() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly")

  return (
    <section id="pricing" className="py-20 md:py-32">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">
            Simple, Transparent Pricing
          </h2>
          <p className="text-lg text-muted-foreground">
            One subscription. Monthly draws. Continuous charity support.
          </p>
        </div>
        
        {/* Billing Toggle */}
        <div className="mt-10 flex items-center justify-center gap-4">
          <button
            onClick={() => setBillingCycle("monthly")}
            className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
              billingCycle === "monthly" 
                ? "bg-primary text-primary-foreground" 
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Monthly
          </button>
          <button
            onClick={() => setBillingCycle("yearly")}
            className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
              billingCycle === "yearly" 
                ? "bg-primary text-primary-foreground" 
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Yearly
            <span className="ml-2 rounded-full bg-accent/20 px-2 py-0.5 text-xs text-accent-foreground">
              Save 17%
            </span>
          </button>
        </div>
        
        <div className="mt-12 grid gap-8 md:grid-cols-2 md:gap-6 lg:max-w-4xl lg:mx-auto">
          {plans.map((plan) => (
            <div 
              key={plan.name}
              className={`relative overflow-hidden rounded-2xl border p-8 ${
                plan.popular 
                  ? "border-primary bg-primary/5 shadow-lg" 
                  : "border-border bg-card"
              }`}
            >
              {plan.popular && (
                <div className="absolute right-4 top-4">
                  <span className="rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className="mb-6">
                <h3 className="text-xl font-semibold text-foreground">{plan.name}</h3>
                <p className="text-sm text-muted-foreground">{plan.description}</p>
              </div>
              
              <div className="mb-6">
                <span className="text-4xl font-bold text-foreground">${plan.price}</span>
                <span className="text-muted-foreground">{plan.period}</span>
                {plan.savings && (
                  <span className="ml-2 rounded-full bg-accent/20 px-2 py-0.5 text-xs font-medium text-accent-foreground">
                    {plan.savings}
                  </span>
                )}
              </div>
              
              <ul className="mb-8 space-y-3">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-3 text-sm text-foreground">
                    <Check className="h-4 w-4 text-primary shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
              
              <Button 
                asChild 
                className="w-full" 
                variant={plan.popular ? "default" : "outline"}
              >
                <Link href={`/auth/sign-up?plan=${plan.name.toLowerCase()}`}>
                  {plan.cta}
                </Link>
              </Button>
            </div>
          ))}
        </div>
        
        <p className="mt-8 text-center text-sm text-muted-foreground">
          All prices in GBP. Cancel your subscription at any time.
        </p>
      </div>
    </section>
  )
}
