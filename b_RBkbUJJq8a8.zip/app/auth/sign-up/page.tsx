"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Check } from "lucide-react"

interface Charity {
  id: string
  name: string
  description: string
}

export default function SignUpPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [selectedCharity, setSelectedCharity] = useState<string>("")
  const [charities, setCharities] = useState<Charity[]>([])
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [step, setStep] = useState(1)
  const router = useRouter()
  const searchParams = useSearchParams()
  const plan = searchParams.get("plan") || "monthly"
  const supabase = createClient()

  useEffect(() => {
    const fetchCharities = async () => {
      const { data } = await supabase
        .from("charities")
        .select("id, name, description")
        .eq("is_active", true)
        .order("is_featured", { ascending: false })
      if (data) setCharities(data)
    }
    fetchCharities()
  }, [supabase])

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setLoading(true)

    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo:
          process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL ??
          `${window.location.origin}/auth/callback`,
        data: {
          full_name: fullName,
        },
      },
    })

    if (error) {
      setError(error.message)
      setLoading(false)
      return
    }

    router.push("/auth/sign-up-success")
  }

  return (
    <div className="flex min-h-screen">
      {/* Left side - Form */}
      <div className="flex w-full flex-col justify-center px-4 py-12 lg:w-1/2 lg:px-12">
        <div className="mx-auto w-full max-w-md">
          <Link href="/" className="mb-8 flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary">
              <span className="text-lg font-bold text-primary-foreground">B</span>
            </div>
            <span className="text-xl font-bold">Birdie Fund</span>
          </Link>

          {/* Progress Steps */}
          <div className="mb-8 flex items-center gap-4">
            <div className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-medium ${
              step >= 1 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
            }`}>
              {step > 1 ? <Check className="h-4 w-4" /> : "1"}
            </div>
            <div className={`h-0.5 flex-1 ${step > 1 ? "bg-primary" : "bg-muted"}`} />
            <div className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-medium ${
              step >= 2 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
            }`}>
              2
            </div>
          </div>

          {step === 1 ? (
            <>
              <h1 className="mb-2 text-3xl font-bold">Create your account</h1>
              <p className="mb-8 text-muted-foreground">
                Join Birdie Fund and start making every round count
              </p>

              {error && (
                <Alert variant="destructive" className="mb-6">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <form onSubmit={(e) => { e.preventDefault(); setStep(2); }} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name</Label>
                  <Input
                    id="fullName"
                    type="text"
                    placeholder="John Smith"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Create a secure password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    minLength={8}
                  />
                  <p className="text-xs text-muted-foreground">
                    Must be at least 8 characters
                  </p>
                </div>

                <Button type="submit" className="w-full">
                  Continue
                </Button>
              </form>
            </>
          ) : (
            <>
              <h1 className="mb-2 text-3xl font-bold">Choose your charity</h1>
              <p className="mb-8 text-muted-foreground">
                Select a charity to support with your subscription
              </p>

              {error && (
                <Alert variant="destructive" className="mb-6">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="mb-6 space-y-3">
                {charities.map((charity) => (
                  <button
                    key={charity.id}
                    type="button"
                    onClick={() => setSelectedCharity(charity.id)}
                    className={`w-full rounded-lg border p-4 text-left transition-all ${
                      selectedCharity === charity.id
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">{charity.name}</h3>
                        <p className="text-sm text-muted-foreground">{charity.description}</p>
                      </div>
                      {selectedCharity === charity.id && (
                        <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary">
                          <Check className="h-4 w-4 text-primary-foreground" />
                        </div>
                      )}
                    </div>
                  </button>
                ))}
              </div>

              <div className="mb-6 rounded-lg border border-border bg-muted/50 p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Selected Plan</span>
                  <span className="font-medium capitalize">{plan}</span>
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Price</span>
                  <span className="font-medium">
                    {plan === "yearly" ? "$99/year" : "$9.99/month"}
                  </span>
                </div>
              </div>

              <div className="flex gap-3">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setStep(1)}
                  disabled={loading}
                >
                  Back
                </Button>
                <Button 
                  type="button" 
                  className="flex-1" 
                  onClick={handleSignUp}
                  disabled={!selectedCharity || loading}
                >
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating account...
                    </>
                  ) : (
                    "Create Account"
                  )}
                </Button>
              </div>
            </>
          )}

          <p className="mt-6 text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link href="/auth/login" className="font-medium text-primary hover:underline">
              Sign in
            </Link>
          </p>
        </div>
      </div>

      {/* Right side - Branding */}
      <div className="hidden bg-primary lg:flex lg:w-1/2 lg:flex-col lg:justify-center lg:p-12">
        <div className="mx-auto max-w-md text-primary-foreground">
          <h2 className="mb-6 text-4xl font-bold">Golf. Give. Win.</h2>
          <p className="mb-8 text-lg text-primary-foreground/80">
            Your subscription supports charity while giving you chances to win monthly prizes.
          </p>
          
          <div className="rounded-xl bg-primary-foreground/10 p-6">
            <h3 className="mb-4 font-semibold">What you get:</h3>
            <ul className="space-y-3 text-primary-foreground/90">
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4" />
                Monthly prize draw entries
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4" />
                10%+ goes to your chosen charity
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4" />
                Track all your golf scores
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4" />
                Dashboard with score history
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}
