"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, ArrowLeft, Shuffle } from "lucide-react"
import Link from "next/link"

export default function NewDrawPage() {
  const [drawDate, setDrawDate] = useState("")
  const [winningNumbers, setWinningNumbers] = useState<number[]>([])
  const [prizePool5, setPrizePool5] = useState("1000")
  const [prizePool4, setPrizePool4] = useState("500")
  const [prizePool3, setPrizePool3] = useState("100")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  const generateRandomNumbers = () => {
    const numbers: number[] = []
    while (numbers.length < 5) {
      const num = Math.floor(Math.random() * 45) + 1
      if (!numbers.includes(num)) {
        numbers.push(num)
      }
    }
    setWinningNumbers(numbers.sort((a, b) => a - b))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    if (winningNumbers.length !== 5) {
      setError("Please generate or enter 5 winning numbers")
      setLoading(false)
      return
    }

    const date = new Date(drawDate)
    const drawMonth = date.getMonth() + 1
    const drawYear = date.getFullYear()

    // Get subscriber count
    const { count: subscriberCount } = await supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })
      .eq("subscription_status", "active")

    const { error: insertError } = await supabase
      .from("draws")
      .insert({
        draw_date: drawDate,
        draw_month: drawMonth,
        draw_year: drawYear,
        status: "pending",
        winning_numbers: winningNumbers,
        prize_pool_5_match: parseFloat(prizePool5),
        prize_pool_4_match: parseFloat(prizePool4),
        prize_pool_3_match: parseFloat(prizePool3),
        total_subscribers: subscriberCount ?? 0
      })

    if (insertError) {
      if (insertError.code === "23505") {
        setError("A draw for this month already exists")
      } else {
        setError(insertError.message)
      }
      setLoading(false)
      return
    }

    router.push("/admin/draws")
    router.refresh()
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/admin/draws">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold">Create New Draw</h1>
          <p className="text-muted-foreground">
            Set up a new monthly prize draw
          </p>
        </div>
      </div>

      <Card className="max-w-2xl">
        <CardHeader>
          <CardTitle>Draw Details</CardTitle>
          <CardDescription>
            Configure the draw date, numbers, and prize pools
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="drawDate">Draw Date</Label>
              <Input
                id="drawDate"
                type="date"
                value={drawDate}
                onChange={(e) => setDrawDate(e.target.value)}
                required
                disabled={loading}
              />
              <p className="text-xs text-muted-foreground">
                Typically the last day of the month
              </p>
            </div>

            <div className="space-y-2">
              <Label>Winning Numbers</Label>
              <div className="flex items-center gap-4">
                <div className="flex gap-2">
                  {[0, 1, 2, 3, 4].map((i) => (
                    <Input
                      key={i}
                      type="number"
                      min={1}
                      max={45}
                      className="w-16 text-center"
                      value={winningNumbers[i] || ""}
                      onChange={(e) => {
                        const newNumbers = [...winningNumbers]
                        newNumbers[i] = parseInt(e.target.value) || 0
                        setWinningNumbers(newNumbers)
                      }}
                      disabled={loading}
                    />
                  ))}
                </div>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={generateRandomNumbers}
                  disabled={loading}
                  className="gap-2"
                >
                  <Shuffle className="h-4 w-4" />
                  Random
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                5 numbers between 1-45
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="prizePool5">5-Match Prize ($)</Label>
                <Input
                  id="prizePool5"
                  type="number"
                  min={0}
                  step={0.01}
                  value={prizePool5}
                  onChange={(e) => setPrizePool5(e.target.value)}
                  required
                  disabled={loading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="prizePool4">4-Match Prize ($)</Label>
                <Input
                  id="prizePool4"
                  type="number"
                  min={0}
                  step={0.01}
                  value={prizePool4}
                  onChange={(e) => setPrizePool4(e.target.value)}
                  required
                  disabled={loading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="prizePool3">3-Match Prize ($)</Label>
                <Input
                  id="prizePool3"
                  type="number"
                  min={0}
                  step={0.01}
                  value={prizePool3}
                  onChange={(e) => setPrizePool3(e.target.value)}
                  required
                  disabled={loading}
                />
              </div>
            </div>

            <div className="flex gap-4">
              <Button type="submit" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating...
                  </>
                ) : (
                  "Create Draw"
                )}
              </Button>
              <Button type="button" variant="outline" asChild disabled={loading}>
                <Link href="/admin/draws">Cancel</Link>
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
