"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Trash2, Target } from "lucide-react"

interface Score {
  id: string
  score: number
  played_date: string
  created_at: string
}

interface ScoresListProps {
  scores: Score[]
  userId: string
}

export function ScoresList({ scores, userId }: ScoresListProps) {
  const [deletingId, setDeletingId] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  const handleDelete = async (id: string) => {
    setDeletingId(id)
    
    await supabase
      .from("golf_scores")
      .delete()
      .eq("id", id)
      .eq("user_id", userId)

    setDeletingId(null)
    router.refresh()
  }

  if (scores.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <Target className="mb-4 h-12 w-12 text-muted-foreground" />
        <h3 className="mb-2 font-semibold">No scores yet</h3>
        <p className="text-sm text-muted-foreground">
          Submit your first score using the form above
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {scores.map((score, index) => (
        <div 
          key={score.id}
          className="flex items-center justify-between rounded-lg border border-border p-4"
        >
          <div className="flex items-center gap-4">
            <div className={`flex h-12 w-12 items-center justify-center rounded-full text-lg font-bold ${
              index < 5 
                ? "bg-primary text-primary-foreground" 
                : "bg-muted text-muted-foreground"
            }`}>
              {score.score}
            </div>
            <div>
              <p className="font-medium">
                {new Date(score.played_date).toLocaleDateString("en-GB", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric"
                })}
              </p>
              <p className="text-sm text-muted-foreground">
                Submitted {new Date(score.created_at).toLocaleDateString()}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            {index < 5 && (
              <Badge variant="secondary">
                Draw #{index + 1}
              </Badge>
            )}
            
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="text-muted-foreground hover:text-destructive"
                  disabled={deletingId === score.id}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete Score</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to delete this score? This will affect your draw numbers 
                    if this score is in your top 5.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={() => handleDelete(score.id)}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      ))}
    </div>
  )
}
