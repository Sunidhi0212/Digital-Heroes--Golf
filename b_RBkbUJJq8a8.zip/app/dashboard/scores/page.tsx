import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScoreEntryForm } from "@/components/dashboard/score-entry-form"
import { ScoresList } from "@/components/dashboard/scores-list"

async function getScoresData(userId: string) {
  const supabase = await createClient()
  
  const { data: scores } = await supabase
    .from("golf_scores")
    .select("*")
    .eq("user_id", userId)
    .order("played_date", { ascending: false })

  return scores ?? []
}

export default async function ScoresPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) return null

  const scores = await getScoresData(user.id)
  const currentNumbers = scores.slice(0, 5).map(s => s.score)

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">My Scores</h1>
        <p className="text-muted-foreground">
          Submit and track your Stableford golf scores
        </p>
      </div>

      {/* Current Draw Numbers */}
      <Card>
        <CardHeader>
          <CardTitle>Your Current Draw Numbers</CardTitle>
          <CardDescription>
            Based on your 5 most recent Stableford scores
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            {currentNumbers.length > 0 ? (
              <>
                {currentNumbers.map((num, i) => (
                  <div 
                    key={i}
                    className="flex h-16 w-16 items-center justify-center rounded-full bg-primary text-2xl font-bold text-primary-foreground"
                  >
                    {num}
                  </div>
                ))}
                {Array.from({ length: Math.max(0, 5 - currentNumbers.length) }).map((_, i) => (
                  <div 
                    key={`empty-${i}`}
                    className="flex h-16 w-16 items-center justify-center rounded-full border-2 border-dashed border-muted text-xl text-muted-foreground"
                  >
                    ?
                  </div>
                ))}
              </>
            ) : (
              <p className="text-muted-foreground">Submit scores to generate your draw numbers</p>
            )}
          </div>
          {currentNumbers.length < 5 && currentNumbers.length > 0 && (
            <p className="mt-4 text-sm text-muted-foreground">
              Submit {5 - currentNumbers.length} more score{5 - currentNumbers.length > 1 ? "s" : ""} to complete your entry
            </p>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-8 lg:grid-cols-2">
        {/* Score Entry Form */}
        <Card>
          <CardHeader>
            <CardTitle>Submit New Score</CardTitle>
            <CardDescription>
              Enter your Stableford score from a recent round
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScoreEntryForm userId={user.id} />
          </CardContent>
        </Card>

        {/* Score Info */}
        <Card>
          <CardHeader>
            <CardTitle>How Scoring Works</CardTitle>
            <CardDescription>
              Understanding the Stableford scoring system
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-medium">Stableford Points</h4>
              <p className="text-sm text-muted-foreground">
                Stableford is a scoring system where points are awarded based on the number of strokes 
                taken at each hole relative to par and your handicap.
              </p>
            </div>
            <div className="rounded-lg bg-muted p-4">
              <h4 className="mb-2 font-medium">Point Values</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>Double Bogey or worse: 0 points</li>
                <li>Bogey: 1 point</li>
                <li>Par: 2 points</li>
                <li>Birdie: 3 points</li>
                <li>Eagle: 4 points</li>
                <li>Albatross: 5 points</li>
              </ul>
            </div>
            <p className="text-sm text-muted-foreground">
              Your total Stableford score typically ranges from <strong>1-45 points</strong>. 
              This score becomes one of your 5 draw numbers.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Scores List */}
      <Card>
        <CardHeader>
          <CardTitle>Score History</CardTitle>
          <CardDescription>
            All your submitted Stableford scores
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScoresList scores={scores} userId={user.id} />
        </CardContent>
      </Card>
    </div>
  )
}
