import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function CTASection() {
  return (
    <section className="border-t border-border bg-primary py-20 md:py-32">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="mb-4 text-3xl font-bold text-primary-foreground md:text-4xl lg:text-5xl">
            Ready to Make Every Round Count?
          </h2>
          <p className="mb-10 text-lg text-primary-foreground/80">
            Join Birdie Fund today and transform your golf game into a force for good. 
            Play golf, support charity, and get chances to win every month.
          </p>
          
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button 
              size="lg" 
              variant="secondary" 
              asChild 
              className="gap-2"
            >
              <Link href="/auth/sign-up">
                Get Started Today
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              asChild
              className="border-primary-foreground/20 bg-transparent text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground"
            >
              <Link href="/#how-it-works">
                Learn More
              </Link>
            </Button>
          </div>
          
          <p className="mt-8 text-sm text-primary-foreground/60">
            No commitment required. Cancel anytime.
          </p>
        </div>
      </div>
    </section>
  )
}
