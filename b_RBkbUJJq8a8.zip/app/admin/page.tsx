import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Trophy, Heart, DollarSign, Target, Calendar } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

async function getAdminStats() {
  const supabase = await createClient()
  
  // Get total users count
  const { count: totalUsers } = await supabase
    .from("profiles")
    .select("*", { count: "exact", head: true })

  // Get active subscribers count
  const { count: activeSubscribers } = await supabase
    .from("profiles")
    .select("*", { count: "exact", head: true })
    .eq("subscription_status", "active")

  // Get total charities
  const { count: totalCharities } = await supabase
    .from("charities")
    .select("*", { count: "exact", head: true })
    .eq("is_active", true)

  // Get total draws
  const { count: totalDraws } = await supabase
    .from("draws")
    .select("*", { count: "exact", head: true })

  // Get recent users
  const { data: recentUsers } = await supabase
    .from("profiles")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(5)

  // Get pending winners
  const { data: pendingWinners, count: pendingWinnersCount } = await supabase
    .from("winners")
    .select("*, profiles(*), draws(*)", { count: "exact" })
    .eq("verification_status", "pending")
    .limit(5)

  // Calculate total prize pool (sum of all subscriptions)
  const { data: subscriptionTotals } = await supabase
    .from("subscriptions")
    .select("prize_pool_amount")
    .eq("status", "active")

  const totalPrizePool = subscriptionTotals?.reduce((sum, s) => sum + Number(s.prize_pool_amount), 0) ?? 0

  return { 
    totalUsers: totalUsers ?? 0, 
    activeSubscribers: activeSubscribers ?? 0,
    totalCharities: totalCharities ?? 0,
    totalDraws: totalDraws ?? 0,
    recentUsers: recentUsers ?? [],
    pendingWinners: pendingWinners ?? [],
    pendingWinnersCount: pendingWinnersCount ?? 0,
    totalPrizePool
  }
}

export default async function AdminPage() {
  const stats = await getAdminStats()

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <p className="text-muted-foreground">
          Overview of Birdie Fund platform statistics
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalUsers}</div>
            <p className="text-xs text-muted-foreground">
              {stats.activeSubscribers} active subscribers
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Prize Pool</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats.totalPrizePool.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">
              From active subscriptions
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Draws</CardTitle>
            <Trophy className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalDraws}</div>
            <p className="text-xs text-muted-foreground">
              Monthly prize draws
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Charities</CardTitle>
            <Heart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalCharities}</div>
            <p className="text-xs text-muted-foreground">
              Active partner charities
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5" />
              Create Draw
            </CardTitle>
            <CardDescription>
              Set up a new monthly prize draw
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/admin/draws/new">Create New Draw</Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Pending Winners
            </CardTitle>
            <CardDescription>
              {stats.pendingWinnersCount} winner{stats.pendingWinnersCount !== 1 ? "s" : ""} awaiting verification
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" asChild>
              <Link href="/admin/draws?tab=winners">Review Winners</Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Heart className="h-5 w-5" />
              Manage Charities
            </CardTitle>
            <CardDescription>
              Add or edit partner charities
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" asChild>
              <Link href="/admin/charities">Manage Charities</Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Recent Users & Pending Winners */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Users</CardTitle>
            <CardDescription>
              Latest user registrations
            </CardDescription>
          </CardHeader>
          <CardContent>
            {stats.recentUsers.length > 0 ? (
              <div className="space-y-4">
                {stats.recentUsers.map((user) => (
                  <div 
                    key={user.id}
                    className="flex items-center justify-between"
                  >
                    <div>
                      <p className="font-medium">{user.full_name || user.email}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(user.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <span className={`rounded-full px-2 py-1 text-xs font-medium ${
                      user.subscription_status === "active" 
                        ? "bg-primary/10 text-primary" 
                        : "bg-muted text-muted-foreground"
                    }`}>
                      {user.subscription_status}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground">No users yet</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Pending Winners</CardTitle>
            <CardDescription>
              Winners awaiting verification
            </CardDescription>
          </CardHeader>
          <CardContent>
            {stats.pendingWinners.length > 0 ? (
              <div className="space-y-4">
                {stats.pendingWinners.map((winner) => (
                  <div 
                    key={winner.id}
                    className="flex items-center justify-between"
                  >
                    <div>
                      <p className="font-medium">{winner.profiles?.email}</p>
                      <p className="text-sm text-muted-foreground">
                        {winner.match_type} - ${winner.prize_amount}
                      </p>
                    </div>
                    <Button size="sm" variant="outline" asChild>
                      <Link href={`/admin/draws?winner=${winner.id}`}>
                        Review
                      </Link>
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground">No pending winners</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
