import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { UserActionsDropdown } from "@/components/admin/user-actions-dropdown"

async function getUsers() {
  const supabase = await createClient()
  
  const { data: users } = await supabase
    .from("profiles")
    .select("*, charities(*)")
    .order("created_at", { ascending: false })

  return users ?? []
}

export default async function AdminUsersPage() {
  const users = await getUsers()

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Users</h1>
        <p className="text-muted-foreground">
          Manage all registered users
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Users</CardTitle>
          <CardDescription>
            {users.length} total user{users.length !== 1 ? "s" : ""}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border text-left text-sm font-medium text-muted-foreground">
                  <th className="pb-3 pr-4">User</th>
                  <th className="pb-3 pr-4">Status</th>
                  <th className="pb-3 pr-4">Plan</th>
                  <th className="pb-3 pr-4">Charity</th>
                  <th className="pb-3 pr-4">Joined</th>
                  <th className="pb-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.id} className="border-b border-border last:border-0">
                    <td className="py-4 pr-4">
                      <div>
                        <p className="font-medium">{user.full_name || "—"}</p>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                      </div>
                    </td>
                    <td className="py-4 pr-4">
                      <Badge variant={user.subscription_status === "active" ? "default" : "secondary"}>
                        {user.subscription_status}
                      </Badge>
                      {user.is_admin && (
                        <Badge variant="outline" className="ml-2">Admin</Badge>
                      )}
                    </td>
                    <td className="py-4 pr-4">
                      <span className="capitalize">{user.subscription_plan || "—"}</span>
                    </td>
                    <td className="py-4 pr-4">
                      <span className="text-sm">{user.charities?.name || "—"}</span>
                    </td>
                    <td className="py-4 pr-4">
                      <span className="text-sm text-muted-foreground">
                        {new Date(user.created_at).toLocaleDateString()}
                      </span>
                    </td>
                    <td className="py-4">
                      <UserActionsDropdown user={user} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
