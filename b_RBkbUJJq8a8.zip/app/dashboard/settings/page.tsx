import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { SubscriptionManager } from "@/components/dashboard/subscription-manager"
import { ProfileForm } from "@/components/dashboard/profile-form"
import Link from "next/link"

async function getSettingsData(userId: string) {
  const supabase = await createClient()
  
  const { data: profile } = await supabase
    .from("profiles")
    .select("*, charities(*)")
    .eq("id", userId)
    .single()

  const { data: subscriptions } = await supabase
    .from("subscriptions")
    .select("*")
    .eq("user_id", userId)
    .eq("status", "active")
    .order("created_at", { ascending: false })
    .limit(1)

  return { profile, subscription: subscriptions?.[0] }
}

export default async function SettingsPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) return null

  const { profile, subscription } = await getSettingsData(user.id)

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Settings</h1>
        <p className="text-muted-foreground">
          Manage your account and subscription
        </p>
      </div>

      {/* Profile Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Profile</CardTitle>
          <CardDescription>
            Update your personal information
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ProfileForm 
            userId={user.id}
            email={user.email ?? ""}
            fullName={profile?.full_name ?? ""}
          />
        </CardContent>
      </Card>

      {/* Subscription */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Subscription</CardTitle>
              <CardDescription>
                Manage your Birdie Fund subscription
              </CardDescription>
            </div>
            <Badge variant={profile?.subscription_status === "active" ? "default" : "secondary"}>
              {profile?.subscription_status === "active" ? "Active" : "Inactive"}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <SubscriptionManager 
            userId={user.id}
            currentStatus={profile?.subscription_status ?? "inactive"}
            currentPlan={profile?.subscription_plan}
            subscription={subscription}
          />
        </CardContent>
      </Card>

      {/* Charity Contribution */}
      <Card>
        <CardHeader>
          <CardTitle>Charity Contribution</CardTitle>
          <CardDescription>
            Adjust how much of your subscription goes to charity
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between rounded-lg border border-border p-4">
              <div>
                <p className="font-medium">Current Contribution</p>
                <p className="text-sm text-muted-foreground">
                  Supporting: {profile?.charities?.name ?? "No charity selected"}
                </p>
              </div>
              <div className="text-2xl font-bold text-primary">
                {profile?.charity_contribution_percentage ?? 10}%
              </div>
            </div>
            
            <p className="text-sm text-muted-foreground">
              Minimum contribution is 10%. You can increase this amount to support your charity even more.
            </p>
            
            <Button variant="outline" asChild>
              <Link href="/dashboard/charity">Manage Charity Settings</Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Account */}
      <Card>
        <CardHeader>
          <CardTitle>Account</CardTitle>
          <CardDescription>
            Manage your account settings
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between rounded-lg border border-border p-4">
            <div>
              <p className="font-medium">Email</p>
              <p className="text-sm text-muted-foreground">{user.email}</p>
            </div>
          </div>
          
          <div className="flex items-center justify-between rounded-lg border border-border p-4">
            <div>
              <p className="font-medium">Password</p>
              <p className="text-sm text-muted-foreground">Last changed: Unknown</p>
            </div>
            <Button variant="outline" size="sm">
              Change Password
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
