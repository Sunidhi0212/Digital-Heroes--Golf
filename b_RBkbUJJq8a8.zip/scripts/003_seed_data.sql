-- Seed initial charities
INSERT INTO public.charities (name, description, logo_url, website_url, is_featured, is_active) VALUES
(
  'Golf for Good Foundation',
  'Supporting junior golfers from underprivileged backgrounds to access quality coaching and equipment.',
  NULL,
  'https://golfforgood.org',
  true,
  true
),
(
  'First Tee',
  'Building game changers by integrating the game of golf with a life skills curriculum.',
  NULL,
  'https://firsttee.org',
  true,
  true
),
(
  'The R&A Foundation',
  'Developing golf globally and ensuring the sport thrives for future generations.',
  NULL,
  'https://randa.org',
  false,
  true
),
(
  'PGA REACH',
  'The charitable foundation of the PGA of America, focused on youth, military, and inclusion.',
  NULL,
  'https://pgareach.org',
  false,
  true
),
(
  'European Tour Foundation',
  'Using golf to transform the lives of young people around the world.',
  NULL,
  'https://europeantour.com/foundation',
  true,
  true
);
