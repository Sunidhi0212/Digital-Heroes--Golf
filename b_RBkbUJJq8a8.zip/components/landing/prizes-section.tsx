import { Trophy, Sparkles, Gift } from "lucide-react"

const prizeTiers = [
  {
    matches: "5 Numbers",
    prize: "Jackpot",
    description: "Match all 5 winning numbers",
    highlight: true,
    icon: Trophy
  },
  {
    matches: "4 Numbers",
    prize: "Major Prize",
    description: "Match 4 of the winning numbers",
    highlight: false,
    icon: Sparkles
  },
  {
    matches: "3 Numbers",
    prize: "Prize Pool Share",
    description: "Match 3 of the winning numbers",
    highlight: false,
    icon: Gift
  }
]

export function PrizesSection() {
  return (
    <section id="prizes" className="py-20 md:py-32">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">
            Monthly Prize Draws
          </h2>
          <p className="text-lg text-muted-foreground">
            Every month, 5 winning numbers are drawn. The more numbers you match, 
            the bigger your share of the prize pool.
          </p>
        </div>
        
        <div className="mt-16 grid gap-6 md:grid-cols-3">
          {prizeTiers.map((tier) => (
            <div 
              key={tier.matches}
              className={`relative overflow-hidden rounded-2xl border p-8 transition-shadow hover:shadow-lg ${
                tier.highlight 
                  ? "border-primary bg-primary/5" 
                  : "border-border bg-card"
              }`}
            >
              {tier.highlight && (
                <div className="absolute right-4 top-4">
                  <span className="rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                    Top Prize
                  </span>
                </div>
              )}
              
              <div className={`mb-4 flex h-14 w-14 items-center justify-center rounded-full ${
                tier.highlight ? "bg-primary/20" : "bg-muted"
              }`}>
                <tier.icon className={`h-7 w-7 ${tier.highlight ? "text-primary" : "text-muted-foreground"}`} />
              </div>
              
              <h3 className="mb-1 text-2xl font-bold text-foreground">{tier.prize}</h3>
              <p className="mb-4 text-lg font-medium text-primary">{tier.matches}</p>
              <p className="text-muted-foreground">{tier.description}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-16 grid gap-6 md:grid-cols-2">
          <div className="rounded-2xl border border-border bg-card p-8">
            <h3 className="mb-4 text-xl font-semibold text-foreground">Prize Pool Distribution</h3>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-primary" />
                Subscription fees fund the monthly prize pool
              </li>
              <li className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-primary" />
                10%+ automatically goes to your chosen charity
              </li>
              <li className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-primary" />
                Remaining funds distributed to winners
              </li>
              <li className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-primary" />
                Unclaimed jackpots roll over to next month
              </li>
            </ul>
          </div>
          
          <div className="rounded-2xl border border-border bg-card p-8">
            <h3 className="mb-4 text-xl font-semibold text-foreground">Fair & Transparent</h3>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-accent" />
                Draw results published publicly each month
              </li>
              <li className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-accent" />
                Winners verified through score submissions
              </li>
              <li className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-accent" />
                Multiple winners share the prize pool equally
              </li>
              <li className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-accent" />
                Full audit trail available
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
