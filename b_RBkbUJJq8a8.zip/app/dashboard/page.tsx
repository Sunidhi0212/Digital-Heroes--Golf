import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Target, Trophy, Heart, Calendar, ArrowRight, AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

async function getDashboardData(userId: string) {
  const supabase = await createClient()
  
  // Get user profile
  const { data: profile } = await supabase
    .from("profiles")
    .select("*, charities(*)")
    .eq("id", userId)
    .single()

  // Get user's golf scores (latest 5)
  const { data: scores } = await supabase
    .from("golf_scores")
    .select("*")
    .eq("user_id", userId)
    .order("played_date", { ascending: false })
    .limit(5)

  // Get user's draw entries
  const { data: drawEntries } = await supabase
    .from("draw_entries")
    .select("*, draws(*)")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .limit(3)

  // Get user's wins
  const { data: wins } = await supabase
    .from("winners")
    .select("*, draws(*)")
    .eq("user_id", userId)
    .eq("verification_status", "approved")

  return { profile, scores: scores ?? [], drawEntries: drawEntries ?? [], wins: wins ?? [] }
}

export default async function DashboardPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) return null

  const { profile, scores, drawEntries, wins } = await getDashboardData(user.id)
  const currentNumbers = scores.map(s => s.score).slice(0, 5)
  const needsMoreScores = currentNumbers.length < 5

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div>
        <h1 className="text-3xl font-bold">Welcome back{profile?.full_name ? `, ${profile.full_name}` : ""}!</h1>
        <p className="text-muted-foreground">
          {"Here's an overview of your Birdie Fund activity."}
        </p>
      </div>

      {/* Subscription Alert */}
      {profile?.subscription_status !== "active" && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Subscription Required</AlertTitle>
          <AlertDescription className="flex items-center justify-between">
            <span>Subscribe to enter monthly prize draws and support charity.</span>
            <Button size="sm" asChild>
              <Link href="/dashboard/settings">Subscribe Now</Link>
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Your Numbers</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              {currentNumbers.length > 0 ? (
                currentNumbers.map((num, i) => (
                  <div 
                    key={i}
                    className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary"
                  >
                    {num}
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground">No scores yet</p>
              )}
              {needsMoreScores && currentNumbers.length > 0 && (
                <>
                  {Array.from({ length: 5 - currentNumbers.length }).map((_, i) => (
                    <div 
                      key={`empty-${i}`}
                      className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-dashed border-muted text-sm text-muted-foreground"
                    >
                      ?
                    </div>
                  ))}
                </>
              )}
            </div>
            {needsMoreScores && (
              <p className="mt-2 text-xs text-muted-foreground">
                Submit {5 - currentNumbers.length} more score{5 - currentNumbers.length > 1 ? "s" : ""} to complete your entry
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Winnings</CardTitle>
            <Trophy className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${profile?.total_winnings ?? "0.00"}</div>
            <p className="text-xs text-muted-foreground">
              {wins.length} win{wins.length !== 1 ? "s" : ""} total
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Charity Support</CardTitle>
            <Heart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{profile?.charity_contribution_percentage ?? 10}%</div>
            <p className="text-xs text-muted-foreground">
              {profile?.charities?.name ?? "No charity selected"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Draw Entries</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{drawEntries.length}</div>
            <p className="text-xs text-muted-foreground">
              Draws participated
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Submit a Score</CardTitle>
            <CardDescription>
              Add your latest Stableford score to update your draw numbers
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="gap-2">
              <Link href="/dashboard/scores">
                Enter Score
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>View Draws</CardTitle>
            <CardDescription>
              Check past and upcoming monthly prize draws
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" asChild className="gap-2">
              <Link href="/dashboard/draws">
                View Draws
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Recent Scores */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Scores</CardTitle>
          <CardDescription>
            Your last 5 Stableford scores form your draw entry numbers
          </CardDescription>
        </CardHeader>
        <CardContent>
          {scores.length > 0 ? (
            <div className="space-y-4">
              {scores.map((score) => (
                <div 
                  key={score.id}
                  className="flex items-center justify-between rounded-lg border border-border p-4"
                >
                  <div>
                    <p className="font-medium">
                      {new Date(score.played_date).toLocaleDateString("en-GB", {
                        weekday: "long",
                        year: "numeric",
                        month: "long",
                        day: "numeric"
                      })}
                    </p>
                  </div>
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-lg font-bold text-primary-foreground">
                    {score.score}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Target className="mb-4 h-12 w-12 text-muted-foreground" />
              <h3 className="mb-2 font-semibold">No scores yet</h3>
              <p className="mb-4 text-sm text-muted-foreground">
                Submit your first Stableford score to start building your draw entry
              </p>
              <Button asChild>
                <Link href="/dashboard/scores">Submit Score</Link>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
