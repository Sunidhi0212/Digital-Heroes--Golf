import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Trophy, Calendar, Target } from "lucide-react"

async function getDrawsData(userId: string) {
  const supabase = await createClient()
  
  // Get published draws
  const { data: draws } = await supabase
    .from("draws")
    .select("*")
    .eq("status", "published")
    .order("draw_date", { ascending: false })
    .limit(12)

  // Get user's draw entries
  const { data: entries } = await supabase
    .from("draw_entries")
    .select("*, draws(*)")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })

  // Get user's current scores for display
  const { data: scores } = await supabase
    .from("golf_scores")
    .select("score")
    .eq("user_id", userId)
    .order("played_date", { ascending: false })
    .limit(5)

  return { 
    draws: draws ?? [], 
    entries: entries ?? [],
    currentNumbers: (scores ?? []).map(s => s.score)
  }
}

export default async function DrawsPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) return null

  const { draws, entries, currentNumbers } = await getDrawsData(user.id)

  // Create a map of user entries by draw id
  const entryByDrawId = new Map(entries.map(e => [e.draw_id, e]))

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Prize Draws</h1>
        <p className="text-muted-foreground">
          View past draw results and check your entries
        </p>
      </div>

      {/* Current Numbers */}
      <Card>
        <CardHeader>
          <CardTitle>Your Current Numbers</CardTitle>
          <CardDescription>
            These numbers will be used in the next draw
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            {currentNumbers.length >= 5 ? (
              currentNumbers.map((num, i) => (
                <div 
                  key={i}
                  className="flex h-14 w-14 items-center justify-center rounded-full bg-primary text-xl font-bold text-primary-foreground"
                >
                  {num}
                </div>
              ))
            ) : (
              <div className="text-muted-foreground">
                {currentNumbers.length === 0 
                  ? "Submit 5 scores to generate your draw numbers"
                  : `Submit ${5 - currentNumbers.length} more score(s) to complete your entry`
                }
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Past Draws */}
      <Card>
        <CardHeader>
          <CardTitle>Past Draws</CardTitle>
          <CardDescription>
            Recent monthly prize draw results
          </CardDescription>
        </CardHeader>
        <CardContent>
          {draws.length > 0 ? (
            <div className="space-y-4">
              {draws.map((draw) => {
                const userEntry = entryByDrawId.get(draw.id)
                const winningNumbers = draw.winning_numbers || []
                
                return (
                  <div 
                    key={draw.id}
                    className="rounded-lg border border-border p-6"
                  >
                    <div className="mb-4 flex flex-wrap items-start justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">
                            {new Date(draw.draw_date).toLocaleDateString("en-GB", {
                              month: "long",
                              year: "numeric"
                            })}
                          </span>
                        </div>
                        <p className="mt-1 text-sm text-muted-foreground">
                          {draw.total_subscribers} participants
                        </p>
                      </div>
                      
                      {userEntry && (
                        <Badge variant={userEntry.is_winner ? "default" : "secondary"}>
                          {userEntry.is_winner 
                            ? `Winner - ${userEntry.match_count} Match${userEntry.match_count > 1 ? "es" : ""}`
                            : "Entered"
                          }
                        </Badge>
                      )}
                    </div>

                    {/* Winning Numbers */}
                    <div className="mb-4">
                      <p className="mb-2 text-sm font-medium text-muted-foreground">Winning Numbers</p>
                      <div className="flex flex-wrap gap-2">
                        {winningNumbers.map((num: number, i: number) => (
                          <div 
                            key={i}
                            className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-lg font-bold text-primary"
                          >
                            {num}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* User's Entry */}
                    {userEntry && (
                      <div>
                        <p className="mb-2 text-sm font-medium text-muted-foreground">Your Entry</p>
                        <div className="flex flex-wrap gap-2">
                          {(userEntry.entered_numbers || []).map((num: number, i: number) => {
                            const isMatch = winningNumbers.includes(num)
                            return (
                              <div 
                                key={i}
                                className={`flex h-10 w-10 items-center justify-center rounded-full text-sm font-bold ${
                                  isMatch 
                                    ? "bg-primary text-primary-foreground" 
                                    : "bg-muted text-muted-foreground"
                                }`}
                              >
                                {num}
                              </div>
                            )
                          })}
                          {userEntry.match_count > 0 && (
                            <span className="ml-2 self-center text-sm font-medium text-primary">
                              {userEntry.match_count} match{userEntry.match_count > 1 ? "es" : ""}!
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Prize Pool Info */}
                    <div className="mt-4 grid gap-2 border-t border-border pt-4 text-sm sm:grid-cols-3">
                      <div>
                        <span className="text-muted-foreground">5 Match: </span>
                        <span className="font-medium">${draw.prize_pool_5_match}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">4 Match: </span>
                        <span className="font-medium">${draw.prize_pool_4_match}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">3 Match: </span>
                        <span className="font-medium">${draw.prize_pool_3_match}</span>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Trophy className="mb-4 h-12 w-12 text-muted-foreground" />
              <h3 className="mb-2 font-semibold">No draws yet</h3>
              <p className="text-sm text-muted-foreground">
                The first monthly draw will be announced soon
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* How Draws Work */}
      <Card>
        <CardHeader>
          <CardTitle>How Draws Work</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start gap-4">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">
              1
            </div>
            <div>
              <h4 className="font-medium">Monthly Draw Date</h4>
              <p className="text-sm text-muted-foreground">
                Draws take place on the last day of each month
              </p>
            </div>
          </div>
          
          <div className="flex items-start gap-4">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">
              2
            </div>
            <div>
              <h4 className="font-medium">5 Numbers Drawn</h4>
              <p className="text-sm text-muted-foreground">
                Five winning numbers between 1-45 are randomly selected
              </p>
            </div>
          </div>
          
          <div className="flex items-start gap-4">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">
              3
            </div>
            <div>
              <h4 className="font-medium">Match to Win</h4>
              <p className="text-sm text-muted-foreground">
                Match 3, 4, or all 5 numbers to win from the prize pool
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
