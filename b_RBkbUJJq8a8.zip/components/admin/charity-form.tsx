"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2 } from "lucide-react"

interface Charity {
  id: string
  name: string
  description: string
  website_url: string
  is_featured: boolean
  is_active: boolean
}

interface CharityFormProps {
  charity?: Charity
  onSuccess?: () => void
}

export function CharityForm({ charity, onSuccess }: CharityFormProps) {
  const [name, setName] = useState(charity?.name ?? "")
  const [description, setDescription] = useState(charity?.description ?? "")
  const [websiteUrl, setWebsiteUrl] = useState(charity?.website_url ?? "")
  const [isFeatured, setIsFeatured] = useState(charity?.is_featured ?? false)
  const [isActive, setIsActive] = useState(charity?.is_active ?? true)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    const charityData = {
      name,
      description,
      website_url: websiteUrl || null,
      is_featured: isFeatured,
      is_active: isActive
    }

    if (charity) {
      // Update existing charity
      const { error: updateError } = await supabase
        .from("charities")
        .update(charityData)
        .eq("id", charity.id)

      if (updateError) {
        setError(updateError.message)
        setLoading(false)
        return
      }
    } else {
      // Create new charity
      const { error: insertError } = await supabase
        .from("charities")
        .insert(charityData)

      if (insertError) {
        setError(insertError.message)
        setLoading(false)
        return
      }
    }

    setLoading(false)
    router.refresh()
    onSuccess?.()
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="space-y-2">
        <Label htmlFor="name">Charity Name</Label>
        <Input
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Cancer Research UK"
          required
          disabled={loading}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Brief description of the charity..."
          rows={3}
          disabled={loading}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="websiteUrl">Website URL</Label>
        <Input
          id="websiteUrl"
          type="url"
          value={websiteUrl}
          onChange={(e) => setWebsiteUrl(e.target.value)}
          placeholder="https://www.charity.org"
          disabled={loading}
        />
      </div>

      <div className="flex items-center justify-between rounded-lg border border-border p-4">
        <div>
          <Label htmlFor="isFeatured">Featured</Label>
          <p className="text-sm text-muted-foreground">
            Featured charities appear first in the list
          </p>
        </div>
        <Switch
          id="isFeatured"
          checked={isFeatured}
          onCheckedChange={setIsFeatured}
          disabled={loading}
        />
      </div>

      <div className="flex items-center justify-between rounded-lg border border-border p-4">
        <div>
          <Label htmlFor="isActive">Active</Label>
          <p className="text-sm text-muted-foreground">
            Inactive charities are hidden from users
          </p>
        </div>
        <Switch
          id="isActive"
          checked={isActive}
          onCheckedChange={setIsActive}
          disabled={loading}
        />
      </div>

      <Button type="submit" className="w-full" disabled={loading}>
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            {charity ? "Updating..." : "Creating..."}
          </>
        ) : (
          charity ? "Update Charity" : "Add Charity"
        )}
      </Button>
    </form>
  )
}
