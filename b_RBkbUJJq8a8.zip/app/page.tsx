import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { HeroSection } from "@/components/landing/hero-section"
import { HowItWorksSection } from "@/components/landing/how-it-works-section"
import { PrizesSection } from "@/components/landing/prizes-section"
import { CharitiesSection } from "@/components/landing/charities-section"
import { PricingSection } from "@/components/landing/pricing-section"
import { CTASection } from "@/components/landing/cta-section"

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <HeroSection />
        <HowItWorksSection />
        <PrizesSection />
        <CharitiesSection />
        <PricingSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  )
}
