"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, CheckCircle } from "lucide-react"

interface ScoreEntryFormProps {
  userId: string
}

export function ScoreEntryForm({ userId }: ScoreEntryFormProps) {
  const [score, setScore] = useState("")
  const [playedDate, setPlayedDate] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setSuccess(false)
    setLoading(true)

    const scoreNum = parseInt(score)
    
    if (isNaN(scoreNum) || scoreNum < 1 || scoreNum > 45) {
      setError("Score must be between 1 and 45 points")
      setLoading(false)
      return
    }

    if (!playedDate) {
      setError("Please select a date")
      setLoading(false)
      return
    }

    // Check if date is in the future
    const selectedDate = new Date(playedDate)
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    
    if (selectedDate > today) {
      setError("Cannot submit scores for future dates")
      setLoading(false)
      return
    }

    const { error: insertError } = await supabase
      .from("golf_scores")
      .insert({
        user_id: userId,
        score: scoreNum,
        played_date: playedDate
      })

    if (insertError) {
      if (insertError.code === "23505") {
        setError("You already have a score for this date")
      } else {
        setError(insertError.message)
      }
      setLoading(false)
      return
    }

    setSuccess(true)
    setScore("")
    setPlayedDate("")
    setLoading(false)
    router.refresh()
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="border-primary/50 bg-primary/5">
          <CheckCircle className="h-4 w-4 text-primary" />
          <AlertDescription className="text-primary">
            Score submitted successfully! Your draw numbers have been updated.
          </AlertDescription>
        </Alert>
      )}

      <div className="space-y-2">
        <Label htmlFor="playedDate">Date Played</Label>
        <Input
          id="playedDate"
          type="date"
          value={playedDate}
          onChange={(e) => setPlayedDate(e.target.value)}
          max={new Date().toISOString().split("T")[0]}
          required
          disabled={loading}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="score">Stableford Score</Label>
        <Input
          id="score"
          type="number"
          min={1}
          max={45}
          placeholder="Enter score (1-45)"
          value={score}
          onChange={(e) => setScore(e.target.value)}
          required
          disabled={loading}
        />
        <p className="text-xs text-muted-foreground">
          Enter your total Stableford points from the round
        </p>
      </div>

      <Button type="submit" className="w-full" disabled={loading}>
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Submitting...
          </>
        ) : (
          "Submit Score"
        )}
      </Button>
    </form>
  )
}
